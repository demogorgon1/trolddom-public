Druid Mod Alpha Patch 1.3 Bug Fixes

Fixed Cultivate lifespores not healing allies
Fixed Wild Growth HoT not ticking 
Fixed compilation errors in Overgrowth tree
Fixed various ground ability visual effects being improperly placed

Bleed Mechanics

Standardized all bleed abilities to match vanilla Fighter patterns
Primal Swipe bleed now correctly deals bleed damage (was nature) — Blood Scent now properly boosts it
Multiple Druids can now stack bleeds on the same target
Added Wolf companion Rend ability

Kinship Tree

Significant updates to the tree, adding three new abilities and fixed duplicate Marked Prey

Overgrowth Tree

Added Urgent Bloom (consumes Verdant Touch to instantly heal for full HoT amount)

Experimental

Attempted fix for crash when interacting with chests, altars, and quest items while shapeshifted — let me know if this is still happening!# Druid Baseline Fix Patches

