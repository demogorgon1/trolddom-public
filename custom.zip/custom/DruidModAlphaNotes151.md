# Druid Mod Alpha Patch Notes

---
## Patch 1.51

### Overgrowth Tree

Grove Keeper Form can now be toggled off by recasting the ability

Placing two Lifespores on the same tile should no longer crash the game. Instead, the second will override the first.

Verdant Nova improvements:

Now correctly damages enemies only (was accidentally hitting allies)
Increased base damage with better level scaling
Added placeholder green explosion visual effect

Living Grove no longer applies debuffs to allies — heals friends, hurts enemies as intended

Lifespore now properly heals the Druid again

### Savagery Tree

Feral Lunge is now a single ability that works in both Cat and Bear Form

### Known Issues

Lifespore healing range is larger than intended


## Patch 1.5

### General
Improved the logic and number spread of all druid healing and damaging abilities. They were mostly static values before.

### Savagery Tree

- Taste for Blood rework: Now correctly scales bonus damage based on the number of bleeds on target. Each bleed consumed adds +30% AP bonus damage Compatible bleeds: Rake, Rip, Thrash, Primal Swipe, Spectral Strike (Wolf), Wolf companion bleed
Note: these numbers show up as separate values, not cumulative. 

- Added Thrash - Replaces Laceration Ability  (Bear Form): New AOE ability granted by Improved Bear Forms. Deals physical damage to nearby enemies and applies a stacking bleed (max 5 stacks). 4s cooldown. Integrates with Taste for Blood and Blood Scent.

- Maul Ability Changes: Now the Druid generates 125% more threat against targets wounded by Maul

- Pounce talent separation: Now a separate chained talent at 10 points requiring Improved Cat Form as prerequisite. Enters stealth for 20s with guaranteed critical strike on next melee attack. Out of combat only.

- Bellow talent separation: Now a separate chained talent at 10 points requiring Improved Bear Form as prerequisite. Previously part of Improved Bear Form R3.

---

## Patch 1.4

### Overgrowth Tree

- Cultivate rework: Originally used a charge system to limit Lifespore placement. Now simply cooldown-based with no cap on active Lifespores. Fungal Network talents improve Lifespore healing by 25/50%. These changes were necessary due to current engine limitations of the environment entity system which handles placed environment abilities. 

- Wild Growth now properly heals companions when targeted directly or when eligible to receive the buff

### Savagery Tree

- Added missing mana costs to certain abilities

### General

- Fixed missing randomness from damage and healing over time ticks

### Upcoming

- Final talents in Improved Cat Form and Improved Bear Form will be broken out into separate chained talents instead of being granted from the base talent improvements

---

## Patch 1.3

### Core Fixes

- Fixed Cultivate lifespores not healing allies
- Fixed Wild Growth HoT not ticking
- Fixed compilation errors in Overgrowth tree

### Bleed Mechanics

- Standardized all bleed abilities to match vanilla Fighter patterns
- Primal Swipe bleed now correctly deals bleed damage (was nature) — Blood Scent now properly boosts it
- Multiple Druids can now stack bleeds on the same target
- Added Wolf companion Rend ability

### Kinship Tree

- Significant updates to the tree, adding three new abilities and fixed duplicate Marked Prey

### Overgrowth Tree

- Added Urgent Bloom (consumes Verdant Touch to instantly heal for full HoT amount)

---

## Patch 1.2

- Initial alpha release to testers
- Three talent trees: Kinship, Overgrowth, Savagery
- Baseline Druid abilities functional
- Shapeshifting forms (Cat, Bear, Travel)
- Companion system basics
