# Druid Mod Alpha Patch Notes

---

## Patch 1.4

### Overgrowth Tree

- Cultivate rework: Originally used a charge system to limit Lifespore placement. Now simply cooldown-based with no cap on active Lifespores. Fungal Network talents improve Lifespore healing by 25/50%. These changes were necessary due to current engine limitations of the environment entity system which handles placed environment abilities. 

- Wild Growth now properly heals companions when targeted directly or when eligible to receive the buff

### Savagery Tree

- Added missing mana costs to certain abilities

### General

- Fixed missing randomness from damage and healing over time ticks

### Upcoming

- Final talents in Improved Cat Form and Improved Bear Form will be broken out into separate chained talents instead of being granted from the base talent improvements

---

## Patch 1.3

### Core Fixes

- Fixed Cultivate lifespores not healing allies
- Fixed Wild Growth HoT not ticking
- Fixed compilation errors in Overgrowth tree

### Bleed Mechanics

- Standardized all bleed abilities to match vanilla Fighter patterns
- Primal Swipe bleed now correctly deals bleed damage (was nature) — Blood Scent now properly boosts it
- Multiple Druids can now stack bleeds on the same target
- Added Wolf companion Rend ability

### Kinship Tree

- Significant updates to the tree, adding three new abilities and fixed duplicate Marked Prey

### Overgrowth Tree

- Added Urgent Bloom (consumes Verdant Touch to instantly heal for full HoT amount)

---

## Patch 1.2

- Initial alpha release to testers
- Three talent trees: Kinship, Overgrowth, Savagery
- Baseline Druid abilities functional
- Shapeshifting forms (Cat, Bear, Travel)
- Companion system basics
